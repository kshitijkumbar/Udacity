#ifndef FORMAT_H
#define FORMAT_H

#include <string>
#include <cmath>

namespace Format {
std::string ElapsedTime(long times);  // TODO: See src/format.cpp
};                                    // namespace Format

#endif