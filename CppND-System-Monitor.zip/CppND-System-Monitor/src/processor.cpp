#include "processor.h"

float Processor::Utilization() { 
    
  const float prevUtilAll = utilAll_;
  const float prevUtilIdle = utilIdle_;  
  utilAll_  = LinuxParser::Jiffies();
  utilIdle_ = LinuxParser::IdleJiffies();

  float delta= (((utilAll_-prevUtilAll)-(utilIdle_-prevUtilIdle)) / (utilAll_-prevUtilAll));
  return (delta>0.0)? delta : 0.0;
 }

 Processor::Processor(){
  utilAll_  = LinuxParser::Jiffies();
  utilIdle_ = LinuxParser::IdleJiffies();  
}
