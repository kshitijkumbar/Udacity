#include "processor.h"

// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
    
  float prevUtilAll = utilAll_;
  float prevUtilIdle = utilIdle_;  
  utilAll_  = LinuxParser::Jiffies();
  utilIdle_ = LinuxParser::IdleJiffies();

  float delta= (((utilAll_-prevUtilAll)-(utilIdle_-prevUtilIdle)) / (utilAll_-prevUtilAll));
  return (delta>0.0)? delta : 0.0;
 }

 Processor::Processor(){
  utilAll_  = LinuxParser::Jiffies();
  utilIdle_ = LinuxParser::IdleJiffies();  
}
