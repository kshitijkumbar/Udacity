#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <iostream>
#include "linux_parser.h"
#include "format.h"
using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os,version, kernel;
  string line;
  std::ifstream stream(kProcDirectory  +  kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

float LinuxParser::MemoryUtilization() { 
   string line;
  string key;
  string value;
  float memTotal = 1;
  float memFree = 0;
  float memCache = 0;
  float memBuffers = 0;
  float memSreclaim = 0;
  float memShmem = 0;
  std::ifstream filestream(kProcDirectory  +  kMeminfoFilename);

  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "MemTotal:") {
      memTotal = stof(value);
      }
      else if (key == "MemFree:") {
      memFree = stof(value);
      }
      else if (key == "Cached:") {
        memCache = stof(value);
      }
      else if (key == "Buffers:") {
        memBuffers = stof(value);
      }
      else if (key == "SReclaimable:" ) {
        memSreclaim = stof(value);
      }
      else if (key == "Shmem:") {
        memShmem = stof(value);
      }
    }
    float totalUsed = memTotal - memFree; 
    float memCacheTotal = memCache  +  memSreclaim - memShmem;
    float actMemUsed = totalUsed - (memCacheTotal  +  memBuffers);
    return actMemUsed/memTotal;
    }
    return 0.0;
  }


long LinuxParser::UpTime() { 
  string line;
  string value;
  std::ifstream filestream(kProcDirectory + kUptimeFilename);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    linestream >> value;
  return (std::stol(value));
  }
  return 0.0;
 }

long LinuxParser::Jiffies() {

  string line;
  string cpu;
  string user ,nice , sys, idle, iowait, irq, sirq, steal, guest, guestNice;

  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    linestream >>cpu >>user >>nice >>sys >>idle >>iowait >>
               irq>>sirq >>steal >> guest >>guestNice;
  }
  return (std::stol(user) + std::stol(nice) + std::stol(sys) + std::stol(irq) + 
          std::stol(sirq) + std::stol(steal) + std::stol(guest) +  
          std::stol(guestNice) + std::stol(idle) + std::stol(iowait));
}

long LinuxParser::ActiveJiffies(int pid) {

  string line, tVal, utime, stime, cutime, cstime;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatFilename);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    for (int i=1; i<14; ++i)
      linestream >> tVal;
    linestream >> utime >> stime>> cutime >>cstime;
  }
  return (std::stol(utime) + std::stol(stime) + std::stol(cutime) + 
          std::stol(cstime));
}

long LinuxParser::ActiveJiffies() {

  string line;
  string cpu;
  string user ,nice , sys, idle, iowait, irq, sirq, steal, guest, guestNice;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    linestream >>cpu >>user >>nice >>sys >>idle >>iowait>>
               irq>>sirq >>steal >> guest >>guestNice;
  }
  return (std::stol(user) + std::stol(nice) + std::stol(sys) + std::stol(irq) + 
          std::stol(sirq) + std::stol(steal) + std::stol(guest) +  std::stol(guestNice));
}

long LinuxParser::IdleJiffies() {

  string line;
  string cpu;
  string user ,nice , sys, idle, iowait, irq, sirq, steal, guest, guestNice;
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    std::istringstream linestream(line);
    linestream >>cpu >>user >>nice >>sys >>idle >>iowait>>
               irq>>sirq >>steal >> guest >>guestNice;
  }
  return (std::stol(idle) + std::stol(iowait));
}

vector<string> LinuxParser::CpuUtilization() { 
  long prevActiveJiffies =ActiveJiffies();
  long prevIdleJiffies = IdleJiffies();
  long currActiveJiffies = ActiveJiffies();
  long currIdleJiffies = IdleJiffies();

  string timeVal = Format::ElapsedTime(
    ((currActiveJiffies-prevActiveJiffies)- (currIdleJiffies-prevIdleJiffies))/ 
     (currActiveJiffies-prevActiveJiffies));
  vector<string> utilizationVec {timeVal};
  return utilizationVec;
 }

int LinuxParser::TotalProcesses() {
  string line;
  string key;
  string value; 
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "processes"){
        return std::stoi(value); 
      } 
    }
  }
  return 0;
}

int LinuxParser::RunningProcesses() {
  string line;
  string key;
  string value; 
  std::ifstream filestream(kProcDirectory + kStatFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "procs_running"){
        return std::stoi(value); 
      } 
    }
  }
  return 0;
 }


string LinuxParser::Command(int pid) { 
  string line;
  std::ifstream filestream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  if (filestream.is_open()) {
    std::getline(filestream, line);
    return line; 
  }
  return ""; 
}

string LinuxParser::Ram(int pid) { 
  string line;
  string key;
  string value; 
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "VmData:"){ 
          int ramData= (100 * std::stof(value)/1024 + 0.5); 
          return to_string(ramData/100) + "." + ((ramData%100 <10) ? "0" + to_string(ramData%100):to_string(ramData%100));
      }
          
    }
  }
  return "";
}

string LinuxParser::Uid(int pid) { 
  string line;
  string key;
  string value; 
  std::ifstream filestream(kProcDirectory + to_string(pid) + kStatusFilename);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::istringstream linestream(line);
      linestream >> key >> value;
      if (key == "Uid:") 
          return value; 
    }
  }
  return "";
}

string LinuxParser::User(int pid) { 
  string line;
  std::ifstream filestream(kPasswordPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      auto pos =line.find("x:" + to_string(pid));
      if (pos != string::npos) 
          return line.substr(0,pos-1); 
    }
  }
  return "root";
 }

long LinuxParser::UpTime(int pid) { 
  std::ifstream fileStream(kProcDirectory + std::to_string(pid) + kStatFilename);
  std::string line;
  if (fileStream.is_open()) {
    std::getline(fileStream, line);
    std::istringstream lineStream(line);
    std::vector<std::string> data{std::istream_iterator<string>{lineStream}, 
    std::istream_iterator<string>{}};
    return UpTime() - std::stol(data[21])/sysconf(_SC_CLK_TCK);
  }
  return 0; }