#include <string>

#include "format.h"

using std::string;

string Format::ElapsedTime(long seconds) { 
    int HH = floor(seconds/3600);
    string HHs = (HH > 9) ? std::to_string(HH%100) : ('0'+ std::to_string(HH%100));
    int MM = floor((seconds - (HH*3600))/60);
    string MMs = (MM > 9) ? std::to_string(MM%100) : ('0'+ std::to_string(MM%100));
    int SS = floor(seconds - (HH*3600) - (MM*60));
    string SSs = (SS > 9) ? std::to_string(SS%100) : ('0'+ std::to_string(SS%100));

    return HHs + ":" + MMs + ":" + SSs;}