#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>

#include "process.h"
#include "linux_parser.h"
using std::string;
using std::to_string;
using std::vector;

 Process::Process(int pid)
 {
     pid_ = pid;
     cpu_ = 0;
     prevProcessCounts = 0;
     prevSystemCounts = 0;
 }

int Process::Pid() { return pid_; }

float Process::CpuUtilization() const { return cpu_; }
void Process::CpuUtilization(long processCounts, long systemCounts) {

  long duration_process = processCounts - prevProcessCounts;
  long duration = systemCounts - prevSystemCounts;

  cpu_ = static_cast<float>(duration_process) / duration;

  prevProcessCounts = processCounts;
  prevSystemCounts = systemCounts;
}
string Process::Command() { return LinuxParser::Command(pid_); }

string Process::Ram() { return LinuxParser::Ram(pid_); }

string Process::User() { return LinuxParser::User(pid_); }

long int Process::UpTime() { return LinuxParser::UpTime(pid_);}

bool Process::operator<(Process const& a) const {
     return (CpuUtilization() < a.CpuUtilization()) ? true :false; 
      }
bool Process::operator>(Process const& a) const {
     return (CpuUtilization() > a.CpuUtilization()) ? true :false; 
      }